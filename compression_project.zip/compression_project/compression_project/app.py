from flask import Flask, render_template, request, send_file
import os
from huffman import compress_to_file, huffman_decompress
import cv2
import numpy as np

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
COMPRESSED_FOLDER = 'compressed'

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(COMPRESSED_FOLDER, exist_ok=True)

def compress_image(input_path, output_path):
    try:
        image = cv2.imread(input_path, cv2.IMREAD_GRAYSCALE)
        if image is None:
            raise ValueError(f"Invalid image: {input_path}")
        dct = cv2.dct(np.float32(image))
        dct[np.abs(dct) < 50] = 0
        compressed_image = cv2.idct(dct)
        cv2.imwrite(output_path, np.uint8(np.clip(compressed_image, 0, 255)))
        return output_path
    except Exception as e:
        print("Image compression error:", e)
        return None

def compress_video(input_path, output_path):
    os.system(f"ffmpeg -i {input_path} -vcodec libx265 -crf 28 {output_path}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/compress_text', methods=['POST'])
def compress_text_route():
    file = request.files['file']
    if file:
        path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(path)
        with open(path, 'r') as f:
            text = f.read()
        out_path = os.path.join(COMPRESSED_FOLDER, file.filename + '.huff')
        compress_to_file(text, out_path)
        return render_template('index.html', text_compressed="Text compressed!", text_compressed_path=out_path)

@app.route('/decompress_text', methods=['POST'])
def decompress_text_route():
    file = request.files['file']
    if file:
        path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(path)
        text = huffman_decompress(path)
        out_path = os.path.join(COMPRESSED_FOLDER, file.filename.replace('.huff', '_decompressed.txt'))
        with open(out_path, 'w') as f:
            f.write(text)
        return render_template('index.html', text_compressed="Text decompressed!", text_compressed_path=out_path)

@app.route('/compress_image', methods=['POST'])
def compress_image_route():
    file = request.files['file']
    if file:
        in_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(in_path)
        out_path = os.path.join(COMPRESSED_FOLDER, file.filename)
        compress_image(in_path, out_path)
        return render_template('index.html', image_compressed="Image compressed!", image_compressed_path=out_path)

@app.route('/compress_video', methods=['POST'])
def compress_video_route():
    file = request.files['file']
    if file:
        in_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(in_path)
        out_path = os.path.join(COMPRESSED_FOLDER, file.filename)
        compress_video(in_path, out_path)
        return render_template('index.html', video_compressed="Video compressed!", video_compressed_path=out_path)

if __name__ == '__main__':
    app.run(debug=True)

import heapq
from collections import defaultdict, Counter
import pickle

class Node:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

    # Define comparators for priority queue
    def __lt__(self, other):
        return self.freq < other.freq

def build_huffman_tree(text):
    freq = Counter(text)
    heap = [Node(ch, fr) for ch, fr in freq.items()]
    heapq.heapify(heap)

    while len(heap) > 1:
        n1 = heapq.heappop(heap)
        n2 = heapq.heappop(heap)
        merged = Node(None, n1.freq + n2.freq)
        merged.left = n1
        merged.right = n2
        heapq.heappush(heap, merged)

    return heap[0]

def build_codes(node, prefix='', code_map=None):
    if code_map is None:
        code_map = {}
    if node.char is not None:
        code_map[node.char] = prefix
    else:
        build_codes(node.left, prefix + '0', code_map)
        build_codes(node.right, prefix + '1', code_map)
    return code_map

def huffman_compress(text):
    root = build_huffman_tree(text)
    codes = build_codes(root)
    encoded_text = ''.join(codes[ch] for ch in text)

    # Save both the encoded text and the code map
    return encoded_text, codes

def compress_to_file(text, filepath):
    encoded_text, code_map = huffman_compress(text)
    with open(filepath, 'wb') as f:
        pickle.dump((encoded_text, code_map), f)
def huffman_decompress(filepath):
    with open(filepath, 'rb') as f:
        encoded_text, code_map = pickle.load(f)

    # Reverse the code map
    reverse_map = {v: k for k, v in code_map.items()}

    # Decode the binary string
    decoded_text = ""
    current_code = ""
    for bit in encoded_text:
        current_code += bit
        if current_code in reverse_map:
            decoded_text += reverse_map[current_code]
            current_code = ""

    return decoded_text
